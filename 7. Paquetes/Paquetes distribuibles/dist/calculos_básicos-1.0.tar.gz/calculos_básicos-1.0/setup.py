from setuptools import setup

setup(

	name="calculos_básicos",
	version="1.0",
	description="Paquete de suma, resta. multiplicación y división",
	author="Adrián",
	author_email="adrifb188@gmail.com",
	url="no tengo",
	packages=["Paquetes","Paquetes.básicos"]

	)