from calculos import *

potencia(2,8)