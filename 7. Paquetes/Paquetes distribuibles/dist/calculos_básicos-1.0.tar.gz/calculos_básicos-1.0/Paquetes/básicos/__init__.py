#un paquete sirve para almacenar módulos relacionados entre sí, debe llamarse __init__.py
def sumar(op1,op2):
	print("El resultado es: ", op1+op2)

def restar(op1,op2):
	print("El resultado es: ", op1-op2)

def multiplicar(op1,op2):
	print("El resultado es: ", op1*op2)

def dividir(op1,op2):
	print("El resultado es: ", op1/op2)

def potencia(op1,op2):
	print("El resultado es: ", op1**op2)

def redondear(nº):
	print("El resultado es: ", round(nº))