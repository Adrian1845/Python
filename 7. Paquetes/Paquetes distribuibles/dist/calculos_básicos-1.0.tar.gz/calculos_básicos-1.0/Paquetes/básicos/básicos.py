def sumar(op1,op2):
	print("El resultado es: ", op1+op2)

def restar(op1,op2):
	print("El resultado es: ", op1-op2)

def multiplicar(op1,op2):
	print("El resultado es: ", op1*op2)

def dividir(op1,op2):
	print("El resultado es: ", op1/op2)