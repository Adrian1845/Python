#un paquete sirve para almacenar módulos relacionados entre sí
#debe llamarse __init__.py para que python lo considere un paquete
from básicos.básicos import *
from redondeo_potencia.redondeo_potencia import *


sumar(3,3)
restar(5,10)

redondeo(4.8)
potencia(10,3)