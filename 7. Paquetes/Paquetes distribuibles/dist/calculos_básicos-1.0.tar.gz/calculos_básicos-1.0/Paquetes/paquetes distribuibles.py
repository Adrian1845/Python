#un paquete distribuible es un paquete que se puede compartir con los usuarios
#creamos un archivo llamado setup.py que contiene la información del paquete
#importamos el setup from setuptools y le damos la información al paquete
#abrimos la consola y vamos hasta el directorio de la carpeta python